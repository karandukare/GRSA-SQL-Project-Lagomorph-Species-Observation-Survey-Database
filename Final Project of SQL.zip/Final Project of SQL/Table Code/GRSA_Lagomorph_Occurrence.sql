CREATE TABLE GRSA_Lagomorph_Occurrence (
    occurrenceID VARCHAR(100) PRIMARY KEY,
    eventID VARCHAR(100) NOT NULL,
    taxonID VARCHAR(100) NOT NULL,
    scientificName VARCHAR(255),
    individualCount INT DEFAULT 0,
    organismQuantity INT DEFAULT 0,
    occurrenceStatus VARCHAR(50)
);