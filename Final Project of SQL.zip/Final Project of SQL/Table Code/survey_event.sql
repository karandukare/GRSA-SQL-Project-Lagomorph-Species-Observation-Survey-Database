CREATE TABLE survey_event (
    eventID TEXT PRIMARY KEY,
    startDateTime TIMESTAMP,
    endDateTime TIMESTAMP,
    countryCode TEXT,
    stateProvince TEXT,
    county TEXT,
    habitatDescription TEXT,
    temperature FLOAT
);