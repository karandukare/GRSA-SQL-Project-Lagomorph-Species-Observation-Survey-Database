CREATE TABLE taxon (
    taxonID TEXT PRIMARY KEY,
    scientificName TEXT,
    family TEXT,
    genus TEXT,
    taxonRank TEXT,
    vernacularName TEXT
);