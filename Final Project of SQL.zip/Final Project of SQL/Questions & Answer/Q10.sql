-- 10. Create a summary table showing each eventID with:
-- A. total individuals observed,
-- B. number of species, and
-- C. average temperature.

SELECT 
    s.eventID,
    COUNT(DISTINCT o.scientificName) AS total_species,
    SUM(o.individualCount) AS total_individuals,
    ROUND(AVG(s.temperature)::numeric, 2) AS avg_temperature
FROM 
    GRSA_Lagomorph_Occurrence AS o
JOIN 
    Survey_Event AS s
ON 
    o.eventID = s.eventID
GROUP BY 
    s.eventID
ORDER BY 
    total_individuals DESC;
