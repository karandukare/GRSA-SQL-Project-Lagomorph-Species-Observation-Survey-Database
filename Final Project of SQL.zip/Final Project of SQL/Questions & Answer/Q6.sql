-- 6. List all survey events (eventID) that lasted more than 2 hours, based on startDateTime and endDateTime.


SELECT 
    eventID,
    startDateTime,
    endDateTime,
    (EXTRACT(EPOCH FROM (endDateTime - startDateTime)) / 3600) AS duration_hours
FROM 
    Survey_Event
WHERE 
    (EXTRACT(EPOCH FROM (endDateTime - startDateTime)) / 3600) > 2
ORDER BY 
    duration_hours DESC;
