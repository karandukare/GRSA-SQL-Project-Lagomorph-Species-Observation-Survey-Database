-- 7. Find all species and events where the species was not observed (i.e., occurrenceStatus = 'absent').

SELECT 
    o.eventID,
    o.scientificName,
    o.occurrenceStatus
FROM 
    GRSA_Lagomorph_Occurrence AS o
WHERE 
    LOWER(o.occurrenceStatus) = 'absent'
ORDER BY 
    o.eventID;
