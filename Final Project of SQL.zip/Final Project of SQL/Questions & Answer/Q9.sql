-- 9. Show the average organism quantity by habitat type and temperature range (e.g. <10°C, 10–20°C, >20°C).


SELECT 
    s.habitatDescription,
    CASE 
        WHEN s.temperature < 10 THEN 'Below 10°C'
        WHEN s.temperature BETWEEN 10 AND 20 THEN '10°C - 20°C'
        WHEN s.temperature > 20 THEN 'Above 20°C'
        ELSE 'Unknown'
    END AS temperature_range,
    ROUND(AVG(o.organismQuantity), 2) AS avg_organism_quantity
FROM 
    GRSA_Lagomorph_Occurrence AS o
JOIN 
    Survey_Event AS s
ON 
    o.eventID = s.eventID
GROUP BY 
    s.habitatDescription, temperature_range
ORDER BY 
    s.habitatDescription, temperature_range;
