-- 4. Find which lagomorph species has the highest total individual count across all survey events.


SELECT 
    o.scientificName,
    SUM(o.individualCount) AS total_individuals
FROM 
    GRSA_Lagomorph_Occurrence AS o
GROUP BY 
    o.scientificName
ORDER BY 
    total_individuals DESC
LIMIT 1;
