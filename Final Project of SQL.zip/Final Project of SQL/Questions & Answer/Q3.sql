-- 3. Find the average temperature at which each lagomorph species was observed.


SELECT 
    o.scientificName,
    ROUND(CAST(AVG(s.temperature) AS numeric), 2) AS avg_temperature
FROM 
    GRSA_Lagomorph_Occurrence AS o
JOIN 
    Survey_Event AS s
ON 
    o.eventID = s.eventID
GROUP BY 
    o.scientificName
ORDER BY 
    avg_temperature DESC;
