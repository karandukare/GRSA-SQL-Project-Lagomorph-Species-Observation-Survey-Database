-- 8. Find species that were recorded in fewer than 3 survey events.


SELECT 
    o.scientificName,
    COUNT(DISTINCT o.eventID) AS total_events
FROM 
    GRSA_Lagomorph_Occurrence AS o
GROUP BY 
    o.scientificName
HAVING 
    COUNT(DISTINCT o.eventID) < 3
ORDER BY 
    total_events ASC;


