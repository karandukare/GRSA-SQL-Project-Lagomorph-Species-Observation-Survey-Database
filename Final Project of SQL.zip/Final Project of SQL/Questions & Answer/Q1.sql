-- 1. How many total observations were recorded for each lagomorph species?


select * from survey_event

SELECT 
    o.scientificName,
    COUNT(o.occurrenceID) AS total_observations
FROM 
    GRSA_Lagomorph_Occurrence AS o
GROUP BY 
    o.scientificName
ORDER BY 
    total_observations DESC;
