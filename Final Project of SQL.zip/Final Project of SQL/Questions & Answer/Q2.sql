-- 2. Which habitat type recorded the highest number of lagomorph occurrences?

SELECT 
    s.habitatDescription,
    COUNT(o.occurrenceID) AS total_occurrences
FROM 
    GRSA_Lagomorph_Occurrence AS o
JOIN 
    Survey_Event AS s
ON 
    o.eventID = s.eventID
GROUP BY 
    s.habitatDescription
ORDER BY 
    total_occurrences DESC
LIMIT 1;
