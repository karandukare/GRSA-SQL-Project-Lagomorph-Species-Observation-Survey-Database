-- 5. Find which county or state recorded the highest number of lagomorph sightings.


SELECT 
    s.stateProvince,
    s.county,
    COUNT(o.occurrenceID) AS total_observations
FROM 
    GRSA_Lagomorph_Occurrence AS o
JOIN 
    Survey_Event AS s
ON 
    o.eventID = s.eventID
GROUP BY 
    s.stateProvince, s.county
ORDER BY 
    total_observations DESC
LIMIT 1;
